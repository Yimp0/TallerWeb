/*
  ═══════════════════════════════════════════════════════════════
  app.js — Pokémon Team Builder
  ───────────────────────────────────────────────────────────────
  Fuentes de datos:
  • PokéAPI        https://pokeapi.co/api/v2/
  • Sprites gen5   https://play.pokemonshowdown.com/sprites/gen5/
  • Sprites dex    https://play.pokemonshowdown.com/sprites/dex/
  ═══════════════════════════════════════════════════════════════
*/


// ════════════════════════════════════════════════════════════════
// 1. CONSTANTES
// ════════════════════════════════════════════════════════════════

const POKEAPI     = 'https://pokeapi.co/api/v2';
const SPRITE_GEN5 = 'https://play.pokemonshowdown.com/sprites/gen5/';
const SPRITE_DEX  = 'https://play.pokemonshowdown.com/sprites/dex/';
const PAGE_SIZE   = 30;
const TEAM_MAX    = 6;

const ALL_TYPES = [
  'normal','fire','water','grass','electric','ice',
  'fighting','poison','ground','flying','psychic','bug',
  'rock','ghost','dragon','dark','steel','fairy'
];

// Las 25 naturalezas con sus efectos (+stat / -stat)
const NATURES = {
  hardy:    { up: null,   down: null   },
  lonely:   { up: 'atk', down: 'def'  },
  brave:    { up: 'atk', down: 'spe'  },
  adamant:  { up: 'atk', down: 'spa'  },
  naughty:  { up: 'atk', down: 'spd'  },
  bold:     { up: 'def', down: 'atk'  },
  docile:   { up: null,   down: null   },
  relaxed:  { up: 'def', down: 'spe'  },
  impish:   { up: 'def', down: 'spa'  },
  lax:      { up: 'def', down: 'spd'  },
  timid:    { up: 'spe', down: 'atk'  },
  hasty:    { up: 'spe', down: 'def'  },
  serious:  { up: null,   down: null   },
  jolly:    { up: 'spe', down: 'spa'  },
  naive:    { up: 'spe', down: 'spd'  },
  modest:   { up: 'spa', down: 'atk'  },
  mild:     { up: 'spa', down: 'def'  },
  quiet:    { up: 'spa', down: 'spe'  },
  bashful:  { up: null,   down: null   },
  rash:     { up: 'spa', down: 'spd'  },
  calm:     { up: 'spd', down: 'atk'  },
  gentle:   { up: 'spd', down: 'def'  },
  sassy:    { up: 'spd', down: 'spe'  },
  careful:  { up: 'spd', down: 'spa'  },
  quirky:   { up: null,   down: null   },
};

const STAT_NAMES = { hp:'HP', atk:'Ataque', def:'Defensa', spa:'At. Esp.', spd:'Def. Esp.', spe:'Velocidad' };
const STAT_KEYS  = ['hp','atk','def','spa','spd','spe'];


// ════════════════════════════════════════════════════════════════
// 2. ESTADO GLOBAL
// ════════════════════════════════════════════════════════════════

const state = {
  // Datos de PokéAPI
  allPokemon: [],     // [{ name, url }] lista completa
  allItems:   [],     // [{ name, url }] lista de items

  // Pokédex page
  dexFiltered:     [],
  dexPage:         0,
  dexActiveTypes:  new Set(),
  dexSearch:       '',

  // Picker (Teambuilder)
  pickerFiltered:    [],
  pickerPage:        0,
  pickerActiveTypes: new Set(),
  pickerSearch:      '',

  // Equipo — array de objetos con datos completos + config del usuario
  team: [null, null, null, null, null, null],
  activeSlot: null,   // índice 0-5 del slot actualmente editado
};

// Caché de datos de Pokémon individuales
const cache = {};


// ════════════════════════════════════════════════════════════════
// 3. UTILIDADES DE SPRITES
// ════════════════════════════════════════════════════════════════

/** Convierte nombre a formato Showdown: "mr-mime" → "mrmime" */
function showdownName(name) {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function spriteUrl(name, type = 'gen5') {
  const base = type === 'dex' ? SPRITE_DEX : SPRITE_GEN5;
  return `${base}${showdownName(name)}.png`;
}

function urlToId(url) {
  const parts = url.split('/').filter(Boolean);
  return parseInt(parts[parts.length - 1], 10);
}


// ════════════════════════════════════════════════════════════════
// 4. FETCH HELPERS
// ════════════════════════════════════════════════════════════════

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function fetchPokemon(nameOrId) {
  const key = String(nameOrId).toLowerCase();
  if (cache[key]) return cache[key];
  const data = await fetchJSON(`${POKEAPI}/pokemon/${key}`);
  cache[key] = data;
  return data;
}

async function fetchTypeNames(typeName) {
  const data = await fetchJSON(`${POKEAPI}/type/${typeName}`);
  return new Set(data.pokemon.map(p => p.pokemon.name));
}


// ════════════════════════════════════════════════════════════════
// 5. CARGA INICIAL
// ════════════════════════════════════════════════════════════════

async function loadInitialData() {
  // Pokémon list
  const pkData          = await fetchJSON(`${POKEAPI}/pokemon?limit=1010&offset=0`);
  state.allPokemon      = pkData.results;
  state.dexFiltered     = [...state.allPokemon];
  state.pickerFiltered  = [...state.allPokemon];

  // Items list (para autocomplete de objeto)
  const itData    = await fetchJSON(`${POKEAPI}/item?limit=2000&offset=0`);
  state.allItems  = itData.results;

  renderPickerGrid();
  renderPickerPagination();
  renderDexGrid();
  renderDexPagination();
}


// ════════════════════════════════════════════════════════════════
// 6. NAVEGACIÓN — SPA sin router externo
// ════════════════════════════════════════════════════════════════

function navigateTo(pageId) {
  // Ocultar todas las páginas
  document.querySelectorAll('.page').forEach(p => p.classList.remove('page-active'));
  // Mostrar la página destino
  const target = document.getElementById(`page-${pageId}`);
  if (target) target.classList.add('page-active');

  // Actualizar botones de nav (header + mobile + footer)
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.page === pageId);
  });

  // Cerrar menú móvil
  document.getElementById('mobile-nav').classList.remove('open');

  // Acciones específicas al cambiar de página
  if (pageId === 'type-analysis')  renderTypeAnalysis();
  if (pageId === 'import-export')  generateExport();
}

// Delegación de eventos para todos los .nav-btn
document.addEventListener('click', e => {
  const btn = e.target.closest('.nav-btn');
  if (btn && btn.dataset.page) navigateTo(btn.dataset.page);
});

// Hamburger móvil
document.getElementById('hamburger').addEventListener('click', () => {
  document.getElementById('mobile-nav').classList.toggle('open');
});


// ════════════════════════════════════════════════════════════════
// 7. EQUIPO — Overview (fila de 6 slots)
// ════════════════════════════════════════════════════════════════

function renderTeamOverview() {
  const row = document.getElementById('team-slots-row');
  row.innerHTML = '';

  for (let i = 0; i < TEAM_MAX; i++) {
    const mon  = state.team[i];
    const div  = document.createElement('div');
    const isSel = state.activeSlot === i;
    div.className   = `team-slot-overview ${mon ? 'filled' : 'empty'} ${isSel ? 'selected' : ''}`;
    div.dataset.index = i;

    if (mon) {
      const cfg = mon._config;
      div.innerHTML = `
        <img src="${spriteUrl(cfg.shiny ? mon.name + '-shiny' : mon.name, 'gen5')}"
             alt="${mon.name}"
             onerror="this.src='${spriteUrl(mon.name,'dex')}'" />
        <span class="slot-overview-name">${cfg.nickname || mon.name}</span>
      `;
    } else {
      div.innerHTML = `<div class="slot-num">${i + 1}</div>`;
    }

    div.addEventListener('click', () => openSlotEditor(i));
    row.appendChild(div);
  }

  // Contador en footer
  const count = state.team.filter(Boolean).length;
  document.getElementById('team-footer-count').textContent = `Equipo: ${count} / 6`;
}


// ════════════════════════════════════════════════════════════════
// 8. EDITOR — Abrir/cerrar slot
// ════════════════════════════════════════════════════════════════

async function openSlotEditor(index) {
  state.activeSlot = index;

  const mon   = state.team[index];
  const empty = document.getElementById('editor-empty-state');
  const form  = document.getElementById('pokemon-editor-form');

  if (!mon) {
    empty.style.display = 'flex';
    form.style.display  = 'none';
    return;
  }

  empty.style.display = 'none';
  form.style.display  = 'block';

  const cfg   = mon._config;
  const types = mon.types.map(t => t.type.name);

  // Sprite y nombre
  document.getElementById('editor-sprite').src =
    cfg.shiny ? spriteUrl(mon.name, 'gen5').replace('.png','-shiny.png') : spriteUrl(mon.name, 'gen5');
  document.getElementById('editor-sprite').onerror = function() { this.src = spriteUrl(mon.name,'dex'); };
  document.getElementById('editor-pokemon-name').textContent = mon.name;

  // Tipos
  document.getElementById('editor-types').innerHTML =
    types.map(t => `<span class="type-badge type-${t}">${t}</span>`).join('');

  // Apodo
  document.getElementById('f-nickname').value = cfg.nickname || '';

  // Formas alternativas
  await populateFormSelect(mon);

  // Habilidades
  populateAbilitySelect(mon, cfg.ability);

  // Naturaleza
  populateNatureSelect(cfg.nature);
  updateNatureEffect(cfg.nature);

  // Movimientos
  populateMoveSelects(mon, cfg.moves);

  // Nivel, género, shiny
  document.getElementById('f-level').value  = cfg.level  || 100;
  document.getElementById('f-gender').value = cfg.gender || 'M';
  document.getElementById('f-shiny').checked = !!cfg.shiny;

  // EVs e IVs
  renderStatInputs('ev', cfg.evs);
  renderStatInputs('iv', cfg.ivs);
  updateEVTotal();

  // Stats finales
  renderFinalStats(mon, cfg);

  // Item
  document.getElementById('f-item').value = cfg.item || '';
}

function closeSlotEditor() {
  state.activeSlot = null;
  document.getElementById('editor-empty-state').style.display = 'flex';
  document.getElementById('pokemon-editor-form').style.display = 'none';
  renderTeamOverview();
}


// ════════════════════════════════════════════════════════════════
// 9. FORMULARIO — Población de selectores
// ════════════════════════════════════════════════════════════════

async function populateFormSelect(mon) {
  const sel = document.getElementById('f-form');
  sel.innerHTML = '<option value="">— Normal —</option>';

  // Buscar formas alternativas en la especie
  try {
    const speciesUrl = mon.species?.url || `${POKEAPI}/pokemon-species/${mon.id}/`;
    const species    = await fetchJSON(speciesUrl);
    if (species.varieties && species.varieties.length > 1) {
      species.varieties.forEach(v => {
        const opt = document.createElement('option');
        opt.value       = v.pokemon.name;
        opt.textContent = v.pokemon.name;
        if (v.pokemon.name === mon.name) opt.selected = true;
        sel.appendChild(opt);
      });
      document.getElementById('form-group-forms').style.display = '';
    } else {
      document.getElementById('form-group-forms').style.display = 'none';
    }
  } catch {
    document.getElementById('form-group-forms').style.display = 'none';
  }

  sel.addEventListener('change', async () => {
    if (!sel.value) return;
    const newMon = await fetchPokemon(sel.value);
    newMon._config = state.team[state.activeSlot]._config;
    state.team[state.activeSlot] = newMon;
    openSlotEditor(state.activeSlot);
  });
}

function populateAbilitySelect(mon, currentAbility) {
  const sel = document.getElementById('f-ability');
  sel.innerHTML = '';
  mon.abilities.forEach(a => {
    const opt       = document.createElement('option');
    opt.value       = a.ability.name;
    opt.textContent = a.is_hidden ? `${a.ability.name} (oculta)` : a.ability.name;
    if (a.ability.name === currentAbility) opt.selected = true;
    sel.appendChild(opt);
  });
}

function populateNatureSelect(currentNature) {
  const sel = document.getElementById('f-nature');
  sel.innerHTML = '';
  Object.keys(NATURES).forEach(name => {
    const opt       = document.createElement('option');
    opt.value       = name;
    opt.textContent = name.charAt(0).toUpperCase() + name.slice(1);
    if (name === currentNature) opt.selected = true;
    sel.appendChild(opt);
  });
  sel.addEventListener('change', () => updateNatureEffect(sel.value));
}

function updateNatureEffect(natureName) {
  const n   = NATURES[natureName];
  const el  = document.getElementById('nature-effect-display');
  if (!n || (!n.up && !n.down)) { el.innerHTML = '<span>Naturaleza neutral</span>'; return; }
  el.innerHTML = `
    <span class="nature-up">↑ ${STAT_NAMES[n.up]}</span>
    <span class="nature-down">↓ ${STAT_NAMES[n.down]}</span>
  `;
}

async function populateMoveSelects(mon, currentMoves = []) {
  const selects = document.querySelectorAll('.f-move');
  // Construir opciones de movimientos del Pokémon
  const moveOptions = mon.moves.map(m => {
    const opt       = document.createElement('option');
    opt.value       = m.move.name;
    opt.textContent = m.move.name;
    return opt;
  });

  selects.forEach((sel, i) => {
    // Guardar valor vacío inicial
    sel.innerHTML = `<option value="">— Movimiento ${i + 1} —</option>`;
    moveOptions.forEach(o => sel.appendChild(o.cloneNode(true)));
    if (currentMoves[i]) sel.value = currentMoves[i];
  });
}


// ════════════════════════════════════════════════════════════════
// 10. EVs e IVs — Renderizado y cálculo
// ════════════════════════════════════════════════════════════════

function renderStatInputs(type, currentValues = {}) {
  const container = document.getElementById(type === 'ev' ? 'ev-sliders' : 'iv-inputs');
  container.innerHTML = '';

  const max    = type === 'ev' ? 252 : 31;
  const defVal = type === 'ev' ? 0   : 31;

  STAT_KEYS.forEach(stat => {
    const val = currentValues[stat] ?? defVal;
    const row = document.createElement('div');
    row.className        = 'stat-row';
    row.dataset.stat     = stat;

    if (type === 'ev') {
      row.innerHTML = `
        <label class="stat-label">${STAT_NAMES[stat]}</label>
        <input type="range"  class="ev-range"  min="0" max="${max}" value="${val}" data-stat="${stat}" />
        <input type="number" class="ev-number" min="0" max="${max}" value="${val}" data-stat="${stat}" />
      `;
      // Sincronizar range ↔ number
      const range  = row.querySelector('.ev-range');
      const number = row.querySelector('.ev-number');
      range.addEventListener('input',  () => { number.value = range.value; updateEVTotal(); updateFinalStats(); });
      number.addEventListener('input', () => { range.value = number.value; updateEVTotal(); updateFinalStats(); });
    } else {
      row.innerHTML = `
        <label class="stat-label">${STAT_NAMES[stat]}</label>
        <input type="number" class="iv-number" min="0" max="${max}" value="${val}" data-stat="${stat}" />
      `;
      row.querySelector('.iv-number').addEventListener('input', updateFinalStats);
    }

    container.appendChild(row);
  });
}

function updateEVTotal() {
  const total = [...document.querySelectorAll('.ev-number')]
    .reduce((sum, el) => sum + (parseInt(el.value) || 0), 0);
  document.getElementById('ev-total-display').textContent = `(${total} / 510)`;
  // Marcar en rojo si pasa de 510
  document.getElementById('ev-total-display').style.color = total > 510 ? 'red' : '';
}

function getEVs() {
  const evs = {};
  document.querySelectorAll('.ev-number').forEach(el => { evs[el.dataset.stat] = parseInt(el.value) || 0; });
  return evs;
}

function getIVs() {
  const ivs = {};
  document.querySelectorAll('.iv-number').forEach(el => { ivs[el.dataset.stat] = parseInt(el.value) ?? 31; });
  return ivs;
}

/** Fórmula oficial de stats Pokémon Gen 3+ */
function calcStat(stat, base, ev, iv, nature, level) {
  const isHP = stat === 'hp';
  const natMod = NATURES[nature]?.up === stat ? 1.1 : NATURES[nature]?.down === stat ? 0.9 : 1;
  if (isHP) {
    return Math.floor(((2 * base + iv + Math.floor(ev / 4)) * level / 100) + level + 10);
  }
  return Math.floor((Math.floor(((2 * base + iv + Math.floor(ev / 4)) * level / 100) + 5) * natMod));
}

function renderFinalStats(mon, cfg) {
  if (!mon) return;
  const container = document.getElementById('final-stats-display');
  container.innerHTML = '';

  const evs    = cfg?.evs   || {};
  const ivs    = cfg?.ivs   || {};
  const nature = cfg?.nature || 'hardy';
  const level  = cfg?.level  || 100;

  mon.stats.forEach(s => {
    const key   = statKeyFromApiName(s.stat.name);
    const base  = s.base_stat;
    const ev    = evs[key] ?? 0;
    const iv    = ivs[key] ?? 31;
    const final = calcStat(key, base, ev, iv, nature, level);
    const pct   = Math.min(100, (final / 714) * 100); // 714 = HP máximo posible aprox.

    const row = document.createElement('div');
    row.className = 'final-stat-row';
    row.innerHTML = `
      <span class="final-stat-name">${STAT_NAMES[key]}</span>
      <div class="final-stat-bar-track">
        <div class="final-stat-bar-fill" style="width:${pct}%"></div>
      </div>
      <span class="final-stat-value">${final}</span>
    `;
    container.appendChild(row);
  });
}

function updateFinalStats() {
  const i = state.activeSlot;
  if (i === null || !state.team[i]) return;
  const cfg = buildConfigFromForm();
  renderFinalStats(state.team[i], cfg);
}

function statKeyFromApiName(apiName) {
  const map = {
    'hp':              'hp',
    'attack':          'atk',
    'defense':         'def',
    'special-attack':  'spa',
    'special-defense': 'spd',
    'speed':           'spe',
  };
  return map[apiName] || apiName;
}


// ════════════════════════════════════════════════════════════════
// 11. ITEM — Autocomplete
// ════════════════════════════════════════════════════════════════

let itemTimer;
document.getElementById('f-item').addEventListener('input', () => {
  clearTimeout(itemTimer);
  const q = document.getElementById('f-item').value.trim().toLowerCase();
  if (q.length < 2) { document.getElementById('item-autocomplete').style.display = 'none'; return; }
  itemTimer = setTimeout(() => showItemAutocomplete(q), 250);
});

function showItemAutocomplete(q) {
  const matches = state.allItems.filter(it => it.name.includes(q)).slice(0, 8);
  const list    = document.getElementById('item-autocomplete');
  if (!matches.length) { list.style.display = 'none'; return; }
  list.innerHTML = matches.map(it => `<li data-name="${it.name}">${it.name}</li>`).join('');
  list.style.display = 'block';
  list.querySelectorAll('li').forEach(li => {
    li.addEventListener('click', () => {
      document.getElementById('f-item').value = li.dataset.name;
      list.style.display = 'none';
    });
  });
}

document.addEventListener('click', e => {
  if (!e.target.closest('#item-search-wrapper')) {
    document.getElementById('item-autocomplete').style.display = 'none';
  }
});


// ════════════════════════════════════════════════════════════════
// 12. GUARDAR CONFIG DEL FORMULARIO
// ════════════════════════════════════════════════════════════════

function buildConfigFromForm() {
  const moves = [...document.querySelectorAll('.f-move')].map(s => s.value).filter(Boolean);
  return {
    nickname: document.getElementById('f-nickname').value.trim(),
    ability:  document.getElementById('f-ability').value,
    item:     document.getElementById('f-item').value.trim(),
    nature:   document.getElementById('f-nature').value,
    moves,
    level:    parseInt(document.getElementById('f-level').value) || 100,
    gender:   document.getElementById('f-gender').value,
    shiny:    document.getElementById('f-shiny').checked,
    evs:      getEVs(),
    ivs:      getIVs(),
  };
}

document.getElementById('editor-save-btn').addEventListener('click', () => {
  const i = state.activeSlot;
  if (i === null || !state.team[i]) return;
  state.team[i]._config = buildConfigFromForm();
  renderTeamOverview();
  saveTeam();
  document.getElementById('editor-save-btn').textContent = '✓ Guardado';
  setTimeout(() => { document.getElementById('editor-save-btn').textContent = '✓ Guardar cambios'; }, 1500);
});

document.getElementById('editor-remove-btn').addEventListener('click', () => {
  if (state.activeSlot === null) return;
  state.team[state.activeSlot] = null;
  closeSlotEditor();
  saveTeam();
});

document.getElementById('clear-team-btn').addEventListener('click', () => {
  if (!state.team.some(Boolean)) return;
  if (confirm('¿Limpiar todo el equipo?')) {
    state.team = [null,null,null,null,null,null];
    closeSlotEditor();
    saveTeam();
  }
});


// ════════════════════════════════════════════════════════════════
// 13. PICKER — Grid de búsqueda/agregar (columna izquierda)
// ════════════════════════════════════════════════════════════════

async function renderPickerGrid() {
  const grid  = document.getElementById('picker-grid');
  const start = state.pickerPage * PAGE_SIZE;
  const slice = state.pickerFiltered.slice(start, start + PAGE_SIZE);

  grid.innerHTML = '<div class="loader">Cargando…</div>';
  if (!slice.length) { grid.innerHTML = '<div class="loader">Sin resultados.</div>'; return; }

  const results = await Promise.allSettled(slice.map(p => fetchPokemon(p.name)));

  grid.innerHTML = results.map(r => {
    if (r.status === 'rejected') return '';
    const p      = r.value;
    const inTeam = state.team.some(m => m && m.id === p.id);
    return `
      <div class="picker-card ${inTeam ? 'in-team' : ''}" data-name="${p.name}">
        <img src="${spriteUrl(p.name,'gen5')}" alt="${p.name}"
             onerror="this.src='${spriteUrl(p.name,'dex')}'" loading="lazy" />
        <div class="picker-name">${p.name}</div>
        <button class="picker-add-btn" data-name="${p.name}">
          ${inTeam ? '✓' : '+'}
        </button>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('.picker-add-btn').forEach(btn => {
    btn.addEventListener('click', () => addToTeam(btn.dataset.name));
  });
}

function renderPickerPagination() {
  renderPagination('picker-pagination', state.pickerFiltered.length, state.pickerPage, p => {
    state.pickerPage = p;
    renderPickerGrid();
    renderPickerPagination();
  });
}

// Búsqueda + filtros del picker
const pickerSearch = document.getElementById('picker-search');
let   pickerSearchTimer;

pickerSearch.addEventListener('input', () => {
  clearTimeout(pickerSearchTimer);
  pickerSearchTimer = setTimeout(() => {
    state.pickerSearch = pickerSearch.value.trim().toLowerCase();
    applyPickerFilters();
    showPickerAutocomplete(state.pickerSearch);
  }, 250);
});

document.getElementById('picker-search-btn').addEventListener('click', () => {
  state.pickerSearch = pickerSearch.value.trim().toLowerCase();
  document.getElementById('picker-autocomplete').style.display = 'none';
  applyPickerFilters();
});

pickerSearch.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    state.pickerSearch = pickerSearch.value.trim().toLowerCase();
    document.getElementById('picker-autocomplete').style.display = 'none';
    applyPickerFilters();
  }
});

function showPickerAutocomplete(q) {
  const list    = document.getElementById('picker-autocomplete');
  const matches = state.allPokemon.filter(p => p.name.includes(q)).slice(0, 6);
  if (q.length < 2 || !matches.length) { list.style.display = 'none'; return; }
  list.innerHTML = matches.map(p => `
    <li data-name="${p.name}">
      <img src="${spriteUrl(p.name,'gen5')}" alt="" onerror="this.src='${spriteUrl(p.name,'dex')}'" />
      ${p.name}
    </li>
  `).join('');
  list.style.display = 'block';
  list.querySelectorAll('li').forEach(li => {
    li.addEventListener('click', () => {
      pickerSearch.value    = li.dataset.name;
      state.pickerSearch    = li.dataset.name;
      list.style.display    = 'none';
      applyPickerFilters();
    });
  });
}

document.addEventListener('click', e => {
  if (!e.target.closest('#picker-search-wrapper')) {
    document.getElementById('picker-autocomplete').style.display = 'none';
  }
});

// Type filter badges del picker
function renderTypeFilters(context) {
  const containerId = context === 'picker' ? 'picker-type-filters' : 'dex-type-filters';
  const container   = document.getElementById(containerId);
  container.innerHTML = '';

  ALL_TYPES.forEach(type => {
    const badge        = document.createElement('span');
    badge.className    = `type-badge type-${type}`;
    badge.textContent  = type;
    badge.addEventListener('click', () => {
      badge.classList.toggle('active');
      if (context === 'picker') {
        state.pickerActiveTypes.has(type) ? state.pickerActiveTypes.delete(type) : state.pickerActiveTypes.add(type);
        applyPickerFilters();
      } else {
        state.dexActiveTypes.has(type) ? state.dexActiveTypes.delete(type) : state.dexActiveTypes.add(type);
        applyDexFilters();
      }
    });
    container.appendChild(badge);
  });
}

async function applyPickerFilters() {
  let list = [...state.allPokemon];
  if (state.pickerSearch) list = list.filter(p => p.name.includes(state.pickerSearch) || String(urlToId(p.url)).includes(state.pickerSearch));
  if (state.pickerActiveTypes.size > 0) {
    const sets = await Promise.all([...state.pickerActiveTypes].map(fetchTypeNames));
    list = list.filter(p => sets.every(s => s.has(p.name)));
  }
  state.pickerFiltered = list;
  state.pickerPage     = 0;
  renderPickerGrid();
  renderPickerPagination();
}


// ════════════════════════════════════════════════════════════════
// 14. AGREGAR AL EQUIPO
// ════════════════════════════════════════════════════════════════

async function addToTeam(name) {
  // Buscar primer slot vacío
  const emptySlot = state.team.findIndex(m => m === null);
  if (emptySlot === -1) { alert('¡Tu equipo ya está completo! (6/6)'); return; }

  const p = await fetchPokemon(name);
  if (state.team.some(m => m && m.id === p.id)) { alert(`${name} ya está en el equipo.`); return; }

  // Config por defecto
  p._config = {
    nickname: '',
    ability:  p.abilities[0]?.ability.name || '',
    item:     '',
    nature:   'hardy',
    moves:    p.moves.slice(0,4).map(m => m.move.name),
    level:    100,
    gender:   'M',
    shiny:    false,
    evs:      { hp:0, atk:0, def:0, spa:0, spd:0, spe:0 },
    ivs:      { hp:31, atk:31, def:31, spa:31, spd:31, spe:31 },
  };

  state.team[emptySlot] = p;
  renderTeamOverview();
  saveTeam();
  await openSlotEditor(emptySlot);  // primero abrir el editor
  renderPickerGrid();                // luego refrescar el picker (sin bloquear)
}


// ════════════════════════════════════════════════════════════════
// 15. POKÉDEX — Grid independiente
// ════════════════════════════════════════════════════════════════

async function renderDexGrid() {
  const grid    = document.getElementById('dex-grid');
  const title   = document.getElementById('dex-results-title');
  const start   = state.dexPage * PAGE_SIZE;
  const slice   = state.dexFiltered.slice(start, start + PAGE_SIZE);

  title.textContent = `${state.dexFiltered.length} Pokémon`;
  grid.innerHTML    = '<div class="loader">Cargando…</div>';
  if (!slice.length) { grid.innerHTML = '<div class="loader">Sin resultados.</div>'; return; }

  const results = await Promise.allSettled(slice.map(p => fetchPokemon(p.name)));

  grid.innerHTML = results.map(r => {
    if (r.status === 'rejected') return '';
    const p     = r.value;
    const types = p.types.map(t => t.type.name);
    return `
      <div class="dex-card" data-name="${p.name}">
        <img src="${spriteUrl(p.name,'gen5')}" alt="${p.name}"
             onerror="this.src='${spriteUrl(p.name,'dex')}'" loading="lazy" />
        <div class="dex-id">#${String(p.id).padStart(4,'0')}</div>
        <div class="dex-name">${p.name}</div>
        <div class="dex-types">
          ${types.map(t => `<span class="type-badge type-${t}">${t}</span>`).join('')}
        </div>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('.dex-card').forEach(card => {
    card.addEventListener('click', () => openDexModal(card.dataset.name));
  });
}

function renderDexPagination() {
  renderPagination('dex-pagination', state.dexFiltered.length, state.dexPage, p => {
    state.dexPage = p;
    renderDexGrid();
    renderDexPagination();
    document.getElementById('page-pokedex').scrollTop = 0;
  });
}

// Búsqueda + filtros de la Pokédex
const dexSearchInput = document.getElementById('dex-search-input');
let   dexSearchTimer;

dexSearchInput.addEventListener('input', () => {
  clearTimeout(dexSearchTimer);
  dexSearchTimer = setTimeout(() => { state.dexSearch = dexSearchInput.value.trim().toLowerCase(); applyDexFilters(); }, 300);
});
document.getElementById('dex-search-btn').addEventListener('click', () => { state.dexSearch = dexSearchInput.value.trim().toLowerCase(); applyDexFilters(); });
document.getElementById('dex-clear-btn').addEventListener('click', () => {
  dexSearchInput.value  = '';
  state.dexSearch       = '';
  state.dexActiveTypes.clear();
  document.querySelectorAll('#dex-type-filters .type-badge').forEach(b => b.classList.remove('active'));
  applyDexFilters();
});

async function applyDexFilters() {
  let list = [...state.allPokemon];
  if (state.dexSearch) list = list.filter(p => p.name.includes(state.dexSearch) || String(urlToId(p.url)).includes(state.dexSearch));
  if (state.dexActiveTypes.size > 0) {
    const sets = await Promise.all([...state.dexActiveTypes].map(fetchTypeNames));
    list = list.filter(p => sets.every(s => s.has(p.name)));
  }
  state.dexFiltered = list;
  state.dexPage     = 0;
  renderDexGrid();
  renderDexPagination();
}

// Modal detalle Pokédex
async function openDexModal(name) {
  const overlay = document.getElementById('dex-modal-overlay');
  const content = document.getElementById('dex-modal-content');
  overlay.classList.add('open');
  content.innerHTML = '<div class="loader">Cargando…</div>';

  try {
    const p     = await fetchPokemon(name);
    const types = p.types.map(t => t.type.name);
    const moves = p.moves.slice(0, 20).map(m => m.move.name);

    const statsHtml = p.stats.map(s => `
      <div class="stat-bar">
        <div class="stat-bar-label">
          <span>${s.stat.name.toUpperCase().replace('-',' ')}</span>
          <span>${s.base_stat}</span>
        </div>
        <div class="stat-bar-track">
          <div class="stat-bar-fill" style="width:${(s.base_stat/255)*100}%"></div>
        </div>
      </div>
    `).join('');

    content.innerHTML = `
      <img class="dex-modal-sprite" src="${spriteUrl(p.name,'dex')}" alt="${p.name}"
           onerror="this.src='${spriteUrl(p.name,'gen5')}'" />
      <h3>${p.name}</h3>
      <div class="dex-modal-id">#${String(p.id).padStart(4,'0')} · ${p.height/10}m · ${p.weight/10}kg</div>
      <div class="dex-modal-types">
        ${types.map(t => `<span class="type-badge type-${t}">${t}</span>`).join('')}
      </div>
      <h4>Base Stats</h4>
      ${statsHtml}
      <h4>Movimientos (primeros 20)</h4>
      <div class="dex-moves-list">
        ${moves.map(m => `<span class="dex-move-tag">${m}</span>`).join('')}
      </div>
      <button id="dex-add-to-team-btn" data-name="${p.name}">+ Añadir al equipo</button>
    `;

    content.querySelector('#dex-add-to-team-btn').addEventListener('click', async () => {
      await addToTeam(p.name);
      closeDexModal();
      navigateTo('teambuilder');
    });
  } catch (err) {
    content.innerHTML = `<div class="loader">Error: ${err.message}</div>`;
  }
}

document.getElementById('dex-modal-close').addEventListener('click', closeDexModal);
document.getElementById('dex-modal-overlay').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeDexModal();
});
function closeDexModal() {
  document.getElementById('dex-modal-overlay').classList.remove('open');
}


// ════════════════════════════════════════════════════════════════
// 16. PAGINACIÓN — Función reutilizable
// ════════════════════════════════════════════════════════════════

function renderPagination(containerId, total, currentPage, onPageChange) {
  const container  = document.getElementById(containerId);
  const totalPages = Math.ceil(total / PAGE_SIZE);
  const p          = currentPage;

  let html = `<button class="pagination-btn" id="${containerId}-prev" ${p===0?'disabled':''}>◀</button>`;
  const start = Math.max(0, p - 2);
  const end   = Math.min(totalPages - 1, p + 2);
  if (start > 0)           html += `<button class="pagination-btn" data-p="0">1</button>${start>1?'<span>…</span>':''}`;
  for (let i = start; i <= end; i++) {
    html += `<button class="pagination-btn ${i===p?'active':''}" data-p="${i}">${i+1}</button>`;
  }
  if (end < totalPages-1)  html += `${end<totalPages-2?'<span>…</span>':''}<button class="pagination-btn" data-p="${totalPages-1}">${totalPages}</button>`;
  html += `<button class="pagination-btn" id="${containerId}-next" ${p>=totalPages-1?'disabled':''}>▶</button>`;

  container.innerHTML = html;
  container.querySelector(`#${containerId}-prev`)?.addEventListener('click', () => onPageChange(p-1));
  container.querySelector(`#${containerId}-next`)?.addEventListener('click', () => onPageChange(p+1));
  container.querySelectorAll('.pagination-btn[data-p]').forEach(btn => {
    btn.addEventListener('click', () => onPageChange(Number(btn.dataset.p)));
  });
}


// ════════════════════════════════════════════════════════════════
// 17. ANÁLISIS DE TIPOS
// ════════════════════════════════════════════════════════════════

// Tabla de efectividad (atacante → defensor)
const TYPE_CHART = {
  normal:   { rock:0.5, ghost:0, steel:0.5 },
  fire:     { fire:0.5, water:0.5, grass:2, ice:2, bug:2, rock:0.5, dragon:0.5, steel:2 },
  water:    { fire:2, water:0.5, grass:0.5, ground:2, rock:2, dragon:0.5 },
  grass:    { fire:0.5, water:2, grass:0.5, poison:0.5, ground:2, flying:0.5, bug:0.5, rock:2, dragon:0.5, steel:0.5 },
  electric: { water:2, grass:0.5, electric:0.5, ground:0, flying:2, dragon:0.5 },
  ice:      { fire:0.5, water:0.5, grass:2, ice:0.5, ground:2, flying:2, dragon:2, steel:0.5 },
  fighting: { normal:2, ice:2, poison:0.5, flying:0.5, psychic:0.5, bug:0.5, rock:2, ghost:0, dark:2, steel:2, fairy:0.5 },
  poison:   { grass:2, poison:0.5, ground:0.5, rock:0.5, ghost:0.5, steel:0, fairy:2 },
  ground:   { fire:2, electric:2, grass:0.5, poison:2, flying:0, bug:0.5, rock:2, steel:2 },
  flying:   { electric:0.5, grass:2, fighting:2, bug:2, rock:0.5, steel:0.5 },
  psychic:  { fighting:2, poison:2, psychic:0.5, dark:0, steel:0.5 },
  bug:      { fire:0.5, grass:2, fighting:0.5, flying:0.5, psychic:2, ghost:0.5, dark:2, steel:0.5, fairy:0.5 },
  rock:     { fire:2, ice:2, fighting:0.5, ground:0.5, flying:2, bug:2, steel:0.5 },
  ghost:    { normal:0, psychic:2, ghost:2, dark:0.5 },
  dragon:   { dragon:2, steel:0.5, fairy:0 },
  dark:     { fighting:0.5, psychic:2, ghost:2, dark:0.5, fairy:0.5 },
  steel:    { fire:0.5, water:0.5, electric:0.5, ice:2, rock:2, steel:0.5, fairy:2 },
  fairy:    { fire:0.5, fighting:2, poison:0.5, dragon:2, dark:2, steel:0.5 },
};

function renderTypeAnalysis() {
  const container = document.getElementById('type-analysis-content');
  const team      = state.team.filter(Boolean);

  if (!team.length) {
    container.innerHTML = '<p class="loader">Agrega Pokémon a tu equipo para ver el análisis.</p>';
    return;
  }

  // Acumular debilidades
  const weaknesses = {};
  const resistances = {};

  team.forEach(mon => {
    const defTypes = mon.types.map(t => t.type.name);
    ALL_TYPES.forEach(attType => {
      let mult = 1;
      defTypes.forEach(defType => {
        mult *= TYPE_CHART[attType]?.[defType] ?? 1;
      });
      if (mult > 1) weaknesses[attType]  = (weaknesses[attType]  || 0) + 1;
      if (mult < 1) resistances[attType] = (resistances[attType] || 0) + 1;
    });
  });

  const makeGrid = (data, label) => {
    const sorted = Object.entries(data).sort((a,b) => b[1]-a[1]);
    if (!sorted.length) return `<p class="loader">Ninguna.</p>`;
    return `<div class="analysis-grid">
      ${sorted.map(([type, count]) => `
        <div class="analysis-type-item">
          <span class="type-badge type-${type}">${type}</span>
          <span class="analysis-count">×${count}</span>
        </div>
      `).join('')}
    </div>`;
  };

  container.innerHTML = `
    <div class="analysis-section">
      <h3>🔴 Debilidades del equipo</h3>
      ${makeGrid(weaknesses)}
    </div>
    <div class="analysis-section">
      <h3>🟢 Resistencias del equipo</h3>
      ${makeGrid(resistances)}
    </div>
  `;
}


// ════════════════════════════════════════════════════════════════
// 18. CALCULADORA DE DAÑO
// ════════════════════════════════════════════════════════════════

document.getElementById('calc-btn').addEventListener('click', calcDamage);

function calcDamage() {
  const atkLevel   = parseInt(document.getElementById('calc-atk-level').value) || 100;
  const atkStat    = parseInt(document.getElementById('calc-atk-stat').value)  || 1;
  const atkNat     = parseFloat(document.getElementById('calc-atk-nature-mod').value);
  const bp         = parseInt(document.getElementById('calc-move-bp').value)   || 1;
  const stab       = parseFloat(document.getElementById('calc-stab').value);
  const defStat    = parseInt(document.getElementById('calc-def-stat').value)  || 1;
  const defNat     = parseFloat(document.getElementById('calc-def-nature-mod').value);
  const defHP      = parseInt(document.getElementById('calc-def-hp').value)    || 1;
  const typeEff    = parseFloat(document.getElementById('calc-type-effectiveness').value);

  // Fórmula simplificada Gen 5+
  const A = Math.floor(atkStat * atkNat);
  const D = Math.floor(defStat * defNat);
  const base = Math.floor(
    (Math.floor((2 * atkLevel) / 5 + 2) * bp * A / D) / 50 + 2
  );
  const dmgMin = Math.floor(base * 0.85 * stab * typeEff);
  const dmgMax = Math.floor(base * 1.00 * stab * typeEff);
  const pctMin = ((dmgMin / defHP) * 100).toFixed(1);
  const pctMax = ((dmgMax / defHP) * 100).toFixed(1);
  const ohko   = dmgMin >= defHP;

  const result = document.getElementById('calc-result');
  result.innerHTML = `
    <div class="calc-result-box ${ohko ? 'ohko' : ''}">
      <div class="calc-damage-range">${dmgMin} – ${dmgMax}</div>
      <div class="calc-pct-range">${pctMin}% – ${pctMax}% del HP</div>
      ${ohko ? '<div class="calc-ohko-label">¡OHKO garantizado!</div>' : ''}
    </div>
  `;
}


// ════════════════════════════════════════════════════════════════
// 19. IMPORT / EXPORT (formato Pokémon Showdown)
// ════════════════════════════════════════════════════════════════

function generateExport() {
  const team = state.team.filter(Boolean);
  if (!team.length) { document.getElementById('export-textarea').value = ''; return; }

  const text = team.map(mon => {
    const cfg   = mon._config;
    const name  = cfg.nickname ? `${cfg.nickname} (${mon.name})` : mon.name;
    const item  = cfg.item  ? ` @ ${cfg.item}` : '';
    const lines = [
      `${name}${item}`,
      `Ability: ${cfg.ability || '—'}`,
      `Level: ${cfg.level || 100}`,
      `${cfg.nature ? cfg.nature.charAt(0).toUpperCase() + cfg.nature.slice(1) : 'Hardy'} Nature`,
      `EVs: ${STAT_KEYS.map(k => `${cfg.evs?.[k]||0} ${STAT_NAMES[k]}`).filter(s=>!s.startsWith('0')).join(' / ') || '—'}`,
      ...(cfg.moves || []).map(m => `- ${m}`),
    ];
    return lines.join('\n');
  }).join('\n\n');

  document.getElementById('export-textarea').value = text;
}

document.getElementById('export-generate-btn').addEventListener('click', generateExport);

document.getElementById('export-copy-btn').addEventListener('click', () => {
  const ta = document.getElementById('export-textarea');
  navigator.clipboard.writeText(ta.value).then(() => {
    document.getElementById('export-copy-btn').textContent = '✓ Copiado';
    setTimeout(() => { document.getElementById('export-copy-btn').textContent = '📋 Copiar'; }, 1500);
  });
});

document.getElementById('import-load-btn').addEventListener('click', async () => {
  const raw      = document.getElementById('import-textarea').value.trim();
  const feedback = document.getElementById('import-feedback');
  if (!raw) { feedback.innerHTML = '<span class="import-error">Pega un equipo primero.</span>'; return; }

  // Parsear formato Showdown: toma el primer "token" de cada bloque
  const blocks = raw.split(/\n\n+/).filter(Boolean);
  const names  = blocks.map(block => {
    const firstLine = block.split('\n')[0];
    // "Nombre @ Item" o "Apodo (nombre) @ Item"
    const match = firstLine.match(/\(([^)]+)\)/);
    if (match) return match[1].toLowerCase().trim();
    return firstLine.split('@')[0].trim().toLowerCase();
  }).slice(0, 6);

  feedback.innerHTML = '<span class="loader">Cargando Pokémon…</span>';
  const pokes = await Promise.all(names.map(n => fetchPokemon(n).catch(() => null)));

  state.team = [null,null,null,null,null,null];
  pokes.filter(Boolean).forEach((p, i) => {
    p._config = {
      nickname:'', ability: p.abilities[0]?.ability.name||'', item:'', nature:'hardy',
      moves: p.moves.slice(0,4).map(m=>m.move.name), level:100, gender:'M', shiny:false,
      evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0}, ivs:{hp:31,atk:31,def:31,spa:31,spd:31,spe:31},
    };
    state.team[i] = p;
  });

  renderTeamOverview();
  renderPickerGrid();
  saveTeam();
  feedback.innerHTML = `<span class="import-success">✓ ${pokes.filter(Boolean).length} Pokémon importados.</span>`;
});


// ════════════════════════════════════════════════════════════════
// 20. PERSISTENCIA en localStorage
// ════════════════════════════════════════════════════════════════

function saveTeam() {
  const data = state.team.map(m => m ? { name: m.name, config: m._config } : null);
  localStorage.setItem('pb_team_v2', JSON.stringify(data));
}

async function loadTeam() {
  const raw = localStorage.getItem('pb_team_v2');
  if (!raw) return;
  try {
    const data  = JSON.parse(raw);
    const pokes = await Promise.all(data.map(d => d ? fetchPokemon(d.name).catch(()=>null) : null));
    pokes.forEach((p, i) => {
      if (!p) return;
      p._config      = data[i].config;
      state.team[i]  = p;
    });
    renderTeamOverview();
    renderPickerGrid();
  } catch { /* localStorage corrupto, ignorar */ }
}


// ════════════════════════════════════════════════════════════════
// 21. INIT
// ════════════════════════════════════════════════════════════════

(async function init() {
  renderTypeFilters('picker');
  renderTypeFilters('dex');
  renderTeamOverview();
  await loadInitialData();
  await loadTeam();
})();